
// Función que funciona cuando se carga la pagina
// document.querySelector("body").onload = async() => {

    const retardo = () => {
        setTimeout(() => {
            console.log('first')
        }, 1000);
    }

    // do {
    // retardo()
    // } while (true);

    // Realiza la petición al servicio que lee el archivo
    // try {
    //     dataConfig = await fetch('http://localhost:3000')
    //     .then(response => {
    //         return response.json();
    //     })
    //     .then(json => {
    //         return json;
    //     })
    // } catch (error) {
    //     console.log(error)
    // }

    // // De acuerdo a lo que hay en el archivo, actualiza los textos de
    // // los botones

    // // Para el Medidor
    // if( String(dataConfig.encenderLed) === 'True' ){
    //     textoBotonMedidor.classList.add('active')
    // } else if( String(dataConfig.encenderLed) === 'False' ){
    //     textoBotonMedidor.classList.remove('active')
    // }
// };
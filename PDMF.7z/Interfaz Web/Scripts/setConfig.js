// Funcion para realizar peticion
const peticionActualiza = async(body) => {
    await fetch('http://localhost:3000', {
        method: 'POST', // or 'PUT'
        headers: {
            'Content-Type': 'text/plain; charset=utf-8',
        },
        body: body
    })
    .then(response => response.json())
    .then(newData => {
        console.log('Success:', newData);
        // Recargar la pagina cuando actualice
        location.reload();
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}

// Funcion al presionar el boton Medidor
const toggleMedidor = () => {
    let newData = {}
    console.log(textoBotonMedidor.classList.contains('active'))

    // Realiza el cambio del valor manteniendo el del motor
    if( textoBotonMedidor.classList.contains('active') === true ){
        newData = {
            "encenderLed":"False",
            "encenderMotor": "False",
            "distancia": dataConfig.distancia
        }
    } else if( textoBotonMedidor.classList.contains('active') === false ){
        newData = {
            "encenderLed":"True",
            "encenderMotor": "False",
            "distancia": dataConfig.distancia
        }
    }

    peticionActualiza(JSON.stringify(newData))
}

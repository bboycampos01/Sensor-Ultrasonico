const textoBotonMedidor = document.querySelector('#btn-medidor');
const spanDistancia = document.querySelector('#medidor');
// const textoBotonMotor = document.querySelector('#btn-motor span')


// Función que funciona cuando se carga la pagina
document.querySelector("body").onload = async() => {
    // Realiza la petición al servicio que lee el archivo
    try {
        dataConfig = await fetch('http://localhost:3000')
        .then(response => {
            return response.json();
        })
        .then(json => {
            return json;
        })
    } catch (error) {
        console.log(error)
    }

    // De acuerdo a lo que hay en el archivo, actualiza los textos de
    // los botones

    // Para el Medidor
    if( String(dataConfig.encenderLed) === 'True' ){
        textoBotonMedidor.classList.add('active')
    } else if( String(dataConfig.encenderLed) === 'False' ){
        textoBotonMedidor.classList.remove('active')
    }

    setInterval(async () => {
        // Realiza la petición al servicio que lee el archivo
        try {
            dataConfig = await fetch('http://localhost:3000')
            .then(response => {
                return response.json();
            })
            .then(json => {
                return json;
            })
        } catch (error) {
            console.log(error)
        }

        // De acuerdo a lo que hay en el archivo, actualiza los textos de
        // los botones

        // Para el Medidor
        if( String(dataConfig.encenderLed) === 'True' ){
            textoBotonMedidor.classList.add('active')
        } else if( String(dataConfig.encenderLed) === 'False' ){
            textoBotonMedidor.classList.remove('active')
        }

        if( dataConfig.distancia <= 10 ){
            spanDistancia.textContent = dataConfig.distancia;
        } else {
            spanDistancia.textContent = 'No'
        }

    }, 100);
};
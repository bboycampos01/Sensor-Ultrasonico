# Carga de bibliotecas
from time import sleep
from rpi_TM1638 import TMBoards
# Definiciones del GPIO
DIO = 21
CLK = 20
STB = 16, 26
# Crear la instancia
TM = TMBoards(DIO, CLK, STB, 0)
TM.clearDisplay()
# Encendido de numeros
TM.segments[0] = '12345678'
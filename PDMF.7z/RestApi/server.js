const express = require('express');
const fs = require('fs');
var cors = require('cors')

const app = express();
const port = 3000;

app.use(express.json({
    type: '*/*',
}));

// Para obtener la información del archivo
app.get('/', cors(), (req, res) => {
    // Lee el archivo
    let rawdata = fs.readFileSync('../config.json');
    let config = JSON.parse(rawdata);
    // Responde con la información del archivo
    res.json(config);
});

// Para modificar la bandera en el archivo
app.post('/', cors(), (req, res) => {
    let newConfig = req.body;
    fs.writeFileSync('../config.json', JSON.stringify(newConfig))
    res.json({message: 'Archivo modificado con exito'});
});

// Se pone en escucha el servidor en el puerto 3000
app.listen(port, () => {
    console.log(`Server listening at port ${port}`)
})